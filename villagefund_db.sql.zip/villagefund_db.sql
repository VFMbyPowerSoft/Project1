-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 
-- รุ่นของเซิร์ฟเวอร์: 5.0.51
-- รุ่นของ PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- ฐานข้อมูล: `villagefund_db`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `employee`
-- 

CREATE TABLE `employee` (
  `empID` int(11) NOT NULL auto_increment,
  `empTitle` varchar(16) NOT NULL,
  `empName` varchar(512) NOT NULL,
  `empLastname` varchar(512) NOT NULL,
  `empNoID` varchar(16) NOT NULL,
  `empUsername` varchar(128) NOT NULL,
  `empPassword` varchar(128) NOT NULL,
  `empHouseNo` varchar(128) NOT NULL,
  `empVillage` varchar(256) NOT NULL,
  `empVillageNo` varchar(128) NOT NULL,
  `empSubdistrict` varchar(128) NOT NULL,
  `empDistrict` varchar(256) NOT NULL,
  `empProvince` varchar(256) NOT NULL,
  `empPostalcode` varchar(256) NOT NULL,
  `empcomday` varchar(16) NOT NULL,
  `empcommonth` varchar(128) NOT NULL,
  `empYear` varchar(16) NOT NULL,
  `empcomstatus` varchar(128) NOT NULL,
  `empTime` varchar(256) NOT NULL,
  PRIMARY KEY  (`empID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

-- 
-- dump ตาราง `employee`
-- 

INSERT INTO `employee` VALUES (5, 'k1', 'k2', 'k3', 'k4', 'k5', 'k6', 'k7', 'k8', 'k9', 'k10', 'k11', 'k12', 'k13', 'k14', 'k15', 'k16', 'k17', '0:2015-03-12 03:24:48');
INSERT INTO `employee` VALUES (6, 'k1', 'k2', 'k3', 'k4', 'k5', 'k6', 'k7', 'k8', 'k9', 'k10', 'k11', 'k12', 'k13', 'k14', 'k15', 'k16', 'k17', '0:2015-03-12 03:36:10');
INSERT INTO `employee` VALUES (7, '', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', 'k', '', '', 'kkkk', '', '0:2015-03-12 03:40:26');
INSERT INTO `employee` VALUES (8, '', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'u', 'uu', 'u', 'u', 'uu', '', '', 'uu', 'สมรส', '0:2015-03-12 04:10:56');
INSERT INTO `employee` VALUES (9, '', '', '', '', 'ball', '1234', '1234', '', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `employee` VALUES (10, '', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', 'f', '', '', '', '', '0:2015-03-12 10:33:27');
INSERT INTO `employee` VALUES (11, '', '', '', '', 'k', 'k', '', '', '', '', '', '', '', '', '', '', '', '0:2015-03-12 10:35:33');
INSERT INTO `employee` VALUES (12, '', '', '', '', 'h', 'h', '', '', '', '', '', '', '', '', '', '', '', '0:2015-03-12 10:43:52');
INSERT INTO `employee` VALUES (13, '', 'h', 'h', '', 'h', 'h', '', '', '', '', '', '', '', '', '', '', '', '0:2015-03-12 10:44:52');
INSERT INTO `employee` VALUES (14, '', 'h', 'h', '', 'h', 'h', '', '', '', '', '', '', '', '', '', '', '', '0:2015-03-12 10:45:22');
INSERT INTO `employee` VALUES (15, '', 'h', 'h', 'h', 'h', 'h', '', '', '', '', '', '', '', '', '', '', '', '0:2015-03-12 10:49:47');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `manager`
-- 

CREATE TABLE `manager` (
  `manID` int(11) NOT NULL auto_increment,
  `manTitle` varchar(16) NOT NULL,
  `manName` varchar(512) NOT NULL,
  `manLastname` varchar(512) NOT NULL,
  `manNoID` varchar(16) NOT NULL,
  `manUsername` varchar(128) NOT NULL,
  `manPassword` varchar(128) NOT NULL,
  `manHouseNo` varchar(128) NOT NULL,
  `manVillage` varchar(256) NOT NULL,
  `manVillageNo` varchar(128) NOT NULL,
  `manSubdistrict` varchar(128) NOT NULL,
  `manDistrict` varchar(256) NOT NULL,
  `manProvince` varchar(256) NOT NULL,
  `manPostalcode` varchar(256) NOT NULL,
  `mancomday` varchar(16) NOT NULL,
  `mancommonth` varchar(128) NOT NULL,
  `manYear` varchar(16) NOT NULL,
  `mancomstatus` varchar(128) NOT NULL,
  `manTime` varchar(256) NOT NULL,
  PRIMARY KEY  (`manID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

-- 
-- dump ตาราง `manager`
-- 

INSERT INTO `manager` VALUES (5, 'นาย', 'วรพล', 'อิ', '1234567890123', 'bally', '1234', '1', 'ไอตีมุง', '1', 'มาโมง', 'สุคิริน', 'นราธิวาส', 'สมรส', 'วันที่', 'เดือน', '2537', 'สมรส', '11:17:14 17-03-2015');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `member`
-- 

CREATE TABLE `member` (
  `IDmem` int(11) NOT NULL auto_increment,
  `memTitle` varchar(16) NOT NULL,
  `memName` varchar(512) NOT NULL,
  `memLastname` varchar(512) NOT NULL,
  `memNoID` varchar(16) NOT NULL,
  `memHouseNo` varchar(128) NOT NULL,
  `memVillage` varchar(256) NOT NULL,
  `memVillageNo` varchar(128) NOT NULL,
  `memSubdistrict` varchar(128) NOT NULL,
  `memDistrict` varchar(256) NOT NULL,
  `memProvice` varchar(256) NOT NULL,
  `memPostalcode` varchar(256) NOT NULL,
  `memcomday` varchar(16) NOT NULL,
  `memcommonth` varchar(128) NOT NULL,
  `memYear` varchar(16) NOT NULL,
  `memcomstatus` varchar(128) NOT NULL,
  `memtimestarted` varchar(256) NOT NULL,
  PRIMARY KEY  (`IDmem`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- dump ตาราง `member`
-- 

